CREATE TABLE user(
    id VARCHAR(10) PRIMARY KEY ,
    name VARCHAR(10),
    pw VARCHAR(20),
    registertime DATE
);