CREATE TABLE student(
    id VARCHAR(10) PRIMARY KEY,
    name VARCHAR(10),
    sex CHAR(4),
    age CHAR(3),
    dept VARCHAR(10)
);