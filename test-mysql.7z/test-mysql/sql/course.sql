CREATE TABLE course(
    id VARCHAR(10) PRIMARY KEY,
    name VARCHAR(10),
    pid VARCHAR(10),
    credit VARCHAR(10)
);