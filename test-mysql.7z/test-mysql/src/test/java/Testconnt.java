import connt.Connt;
import org.junit.Test;

public class Testconnt {
    @Test
    public void test(){
        Connt.getConnection();
    }
}
