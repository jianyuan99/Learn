import gui.windows1.Windows1;

/**
 * @ClassName WindowsTest
 * @Description 窗口测试
 * @Author Huangbiao
 * @Version V1.0
 */
public class WindowsTest {
    public static void main(String[] args) {
        Windows1 windows1 = new Windows1("学生信息管理系统");
    }

}
